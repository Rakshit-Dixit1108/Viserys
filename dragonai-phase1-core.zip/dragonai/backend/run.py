"""Convenience entrypoint: `python run.py` starts the API with hot reload."""
import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
